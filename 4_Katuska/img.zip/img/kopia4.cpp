                  ^|*|^                /
                  ^|*|^                /
sgjnl             ^|1|^                /
sgjnl             ^|2|^                /
sgjnl             ^|3|^                /
sgjnl              \4/                 /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *

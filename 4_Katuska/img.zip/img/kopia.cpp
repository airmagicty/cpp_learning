                  ^||^                 /
                  ^||^                 /
sgjnl              \/                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
========================================
                  ^||^                 /
                  ^||^                 /
sgjnl             ^||^                 /
sgjnl              \/                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
========================================
                  ^||^                 /
                  ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl              \/                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
========================================
                  ^||^                 /
                  ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl              \/                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
========================================
                  ^||^                 /
                  ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl              \/                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
========================================
                  ^||^                 /
                  ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl              \/                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
========================================
                  ^||^                 /
                  ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl              \/                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
========================================
                  ^||^                 /
                  ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl              \/                  /
sgjnl                                  /
sgjnl                                  /
========================================
                  ^||^                 /
                  ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl              \/                  /
sgjnl                                  /
========================================
                  ^||^                 /
                  ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl             ^||^                 /
sgjnl              \/                  /
========================================

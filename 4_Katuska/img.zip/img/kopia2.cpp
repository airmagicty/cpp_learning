                  ^|*|^                /
                  ^|*|^                /
sgjnl             ^|1|^                /
sgjnl              \2/                 /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *

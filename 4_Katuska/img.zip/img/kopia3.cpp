                  ^|*|^                /
                  ^|*|^                /
sgjnl             ^|1|^                /
sgjnl             ^|2|^                /
sgjnl              \3/                 /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *

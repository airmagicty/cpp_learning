                  ^|*|^                /
                  ^|*|^                /
sgjnl             ^|1|^                /
sgjnl             ^|2|^                /
sgjnl             ^|3|^                /
sgjnl             ^|4|^                /
sgjnl             ^|5|^                /
sgjnl             ^|6|^                /
sgjnl             ^|7|^                /
sgjnl              \8/                 /
sgjnl                                  /
sgjnl                                  /
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *

                  ^|*|^                /
                  ^|*|^                /
sgjnl             ^|1|^                /
sgjnl             ^|2|^                /
sgjnl             ^|3|^                /
sgjnl             ^|4|^                /
sgjnl             ^|5|^                /
sgjnl              \6/                 /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
sgjnl                                  /
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *
*                                      *

|======|---3---|==============================================================|
|                                                                        HHHHH|
|                                                                        HHHHH|
|                                                                        DDDDD|
|                                                                        DD2DD|
|                                                                        DDDDD|
|                                                                        DDDDD|
|                                                                        DDDDD|
|                                                                             |
|                                                                             |
|                                 o                                           |
|                                /A\                                          |
|                                / \                                          |
|                                                                             |
|                                <Vnimaniye!                                  |
|                                <Teper  u vas yest  predmet v "Inventory"!   |
|                                <Vy mozhete im polzovatsya!                  |
|                                                          ====               |
|------                                                       =    |Inventory:|
|_____|                                                       ==>> |*Doska    |
|__1__;                                                            |*         |
|_____|                                                            |*         |
|===================================_____=====================================|

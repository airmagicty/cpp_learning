|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                        <Privet, polzovatel!                                 |
|                        <Ya tvoy novyy personazh!                            |
|                        <Mne ochen priyatno s toboy poznakomitsya.           |
|           o            <YA nachnu s togo, i ya ne mogu vse sam delat,       |
|          /A\           chto ya vsego lish programmnyy personazh,            |
|          / \           po etomu tebe priydetsya upravlyat mnoy,             |
|                        a ya budu tebe podskazyvat...                        |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |

|                                                                             |
|                                     h             t                         |
|                sss   u   u    ccc   h      eeee   t                         |
|               s      u   u   c   c  h      e     tttt                       |
|                sss   u   u   c      hhhh   eee    t                         |
|                   s  u   u   c   c  h   h  e      t                         |
|                sss    uuu u   ccc   h   h  eeee    ttt                      |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |

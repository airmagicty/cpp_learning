|======|---3---|==============================================================|
|         /\                                                             HHHHH|
|        Okno                                                            HHHHH|
|                                                                        DDDDD|
|                                                               Krovat>  DD2DD|
|                                                                        DDDDD|
|                                                                        DDDDD|
|                                                                        DDDDD|
|                                                                             |
|                                                                             |
|                                 o  <ID predmetov podpisan na predmetakh.    |
|                                /A\ <Chtoby vzaimodeystvovat s nimi nado     |
|                                / \  vvesti ID predmeta.                     |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|------                                                            |Inventory:|
|_____| <Shkaf                                                     |*         |
|__1__;                              Dver X                        |*         |
|_____|                               \/                           |*         |
|===================================_____=====================================|

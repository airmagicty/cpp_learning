|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                   EEEEEEEE  NN      NN  DDDDDD                              |
|                   EE        NN NN   NN  DD    D                             |
|                   EE        NN  NN  NN  DD     D                            |
|                   EEEEEEE   NN  NN  NN  DD     D                            |
|                   EE        NN   NN NN  DD     D                            |
|                   EE        NN    NNNN  DD    D                             |
|                   EEEEEEEE  NN      NN  DDDDDD                              |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |

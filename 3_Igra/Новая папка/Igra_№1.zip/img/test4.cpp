|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                               Hello, User!                                  |
|                                                                             |
|                            Welcome to my game!                              |
|                                                                             |
|                                                                             |
|                            |||||||||||||||||||                              |
|                           || ggggg      ooo  ||                             |
|                           ||g          o   o ||                             |
|                           ||g   ggg   o     o||                             |
|                           ||g     g    o   o ||                             |
|                           || ggggg      ooo  ||                             |
|                            |||||||||||||||||||                              |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |

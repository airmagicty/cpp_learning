|                                                                             |
|                                                                             |
|                                                                             |
|             mm         mm  eeeeeee  nn     nn  uu     uu    @@              |
|             mm mm   mm mm  ee       nn n   nn  uu     uu    @@              |
|             mm  mm mm  mm  eeeeee   nn  n  nn  uu     uu                    |
|             mm   mm    mm  ee       nn   n nn  uu     uu    @@              |
|             mm         mm  eeeeeee  nn    nnn    uuuuu      @@              |
|                                                                             |
|                                                                             |
|                                                                             |
|                              Start the Game {1}                             |
|                                                                             |
|                                                                             |
|                                 Syuzhet {2}                                 |
|                                                                             |
|                                                                             |
|                         >>      Ob igre {3}                                 |
|                                                                             |
|                                                                             |
|                                   Exit {4}                                  |
|                                                                             |
|                                                                             |
|                                                                             |

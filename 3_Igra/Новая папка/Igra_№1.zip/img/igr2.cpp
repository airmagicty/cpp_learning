|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                        <Privet, polzovatel!                                 |
|                        <Ya tvoy novyy personazh!                            |
|                                                                             |
|           o                                                                 |
|          /A\                                                                |
|          / \                                                                |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |

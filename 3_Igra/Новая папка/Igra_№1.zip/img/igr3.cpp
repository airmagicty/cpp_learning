|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                        <Privet, polzovatel!                                 |
|                        <Ya tvoy novyy personazh!                            |
|                        <Mne ochen priyatno s toboy poznakomitsya.           |
|           o                                                                 |
|          /A\                                                                |
|          / \                                                                |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
|                                                                             |
